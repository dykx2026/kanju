﻿# LibreTV local launcher: loopback only, password protected
# URL: http://127.0.0.1:3000
# 双击这个快捷方式时窗口是可见的：能看到它在干什么，就绪后自己关掉。
# 注意：LIVE_ALLOW_PRIVATE=1 是必须的 —— 否则 LibreTV 的 SSRF 防护会把
#       指向 127.0.0.1 的「本地加速」源当成非法地址直接拒掉。
$ErrorActionPreference = 'Continue'

$Root   = Join-Path $PSScriptRoot 'libretv'
$Node   = 'D:\Apps\node\node.exe'
$Port   = 3000
$Pass   = '040118'
$Url    = "http://127.0.0.1:$Port"
$Accel  = 'http://127.0.0.1:3001'

try { $Host.UI.RawUI.WindowTitle = 'LibreTV 启动中...' } catch { }

function Open-UI {
    # 不用 Start-Process $Url：隐藏会话里它偶尔什么都不做也不报错。
    # rundll32 走 FileProtocolHandler，等价于资源管理器里双击链接。
    try {
        Start-Process -FilePath 'rundll32.exe' -ArgumentList "url.dll,FileProtocolHandler $Url" -WindowStyle Hidden
    } catch {
        try { Start-Process $Url } catch { }
    }
}

if (-not (Test-Path $Node)) {
    Write-Host "找不到 node.exe：$Node" -ForegroundColor Red
    Read-Host "按回车关闭"
    exit 1
}
if (-not (Test-Path (Join-Path $Root 'server.js'))) {
    Write-Host "找不到 server.js：$Root" -ForegroundColor Red
    Read-Host "按回车关闭"
    exit 1
}

# 加速器先起来：LibreTV 的「本地加速」源指着它，没它播放会失败
$accelBusy = $null
try { $accelBusy = Get-NetTCPConnection -LocalPort 3001 -State Listen -ErrorAction SilentlyContinue } catch { }
if (-not $accelBusy -and (Test-Path (Join-Path $PSScriptRoot 'hls_accel.js'))) {
    Write-Host "启动 HLS 加速代理（127.0.0.1:3001）..." -ForegroundColor Cyan
    Start-Process -FilePath $Node -ArgumentList 'hls_accel.js','3001' -WorkingDirectory $PSScriptRoot -WindowStyle Hidden | Out-Null
    for ($i = 1; $i -le 20; $i++) {
        Start-Sleep -Milliseconds 300
        try { if (Get-NetTCPConnection -LocalPort 3001 -State Listen -ErrorAction SilentlyContinue) { break } } catch { }
    }
}

# 端口上已经有监听 → 直接开浏览器，不重复起服务
$busy = $null
try { $busy = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue } catch { }
if ($busy) {
    Write-Host "LibreTV 已在运行（PID $($busy.OwningProcess -join ',')），正在打开浏览器..." -ForegroundColor Green
    Open-UI
    Start-Sleep -Seconds 1
    exit 0
}

$env:HOSTNAME           = '127.0.0.1'
$env:PORT               = "$Port"
$env:NODE_ENV           = 'production'
$env:PASSWORD           = $Pass
$env:COOKIE_SECURE      = 'false'
# 允许把点播源地址指向回环地址（本地加速器）
$env:LIVE_ALLOW_PRIVATE = '1'

Write-Host "正在启动 LibreTV（仅本机 127.0.0.1，带密码）..." -ForegroundColor Cyan
$p = Start-Process -FilePath $Node -ArgumentList 'server.js' -WorkingDirectory $Root `
     -WindowStyle Hidden -PassThru
if (-not $p) {
    Write-Host "启动 node 失败。" -ForegroundColor Red
    Read-Host "按回车关闭"
    exit 1
}
Write-Host "进程 PID $($p.Id)，等待应答..."

$ok = $false
for ($i = 1; $i -le 40; $i++) {
    Start-Sleep -Milliseconds 500
    if ($p.HasExited) { break }
    try {
        $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2
        if ($r.StatusCode -eq 200) { $ok = $true; break }
    } catch { }
    if ($i % 4 -eq 0) { Write-Host ("  还在等（{0:N1} 秒）..." -f ($i * 0.5)) }
}

if ($ok) {
    Write-Host "就绪：$Url  密码 $Pass" -ForegroundColor Green
    Write-Host "加速器：$Accel（网页设置里的「本地加速」源）" -ForegroundColor Green
    Open-UI
    Start-Sleep -Seconds 1
    exit 0
}

Write-Host "启动了但没应答。排查：netstat -ano | findstr :$Port" -ForegroundColor Yellow
Read-Host "按回车关闭"
exit 1
