﻿LibreTV 本地版 使用说明
=====================================

【启动】
  双击 start-localtv.ps1（右键 → 使用 PowerShell 运行）
  它会先起加速器（127.0.0.1:3001），再起 LibreTV（127.0.0.1:3000），
  等就绪后自动打开浏览器。

【密码】
  040118        改 start-localtv.ps1 里的 PASSWORD 一行即可更换。

【播放源】
  本包不内置任何采集源。源地址见仓库根目录 README.md 的「播放源」一节。
  填写位置：hls_accel.js 开头的 const SOURCES = [ ... ];

【两个必须注意的点】
  1. start-localtv.ps1 里的 node 路径写死了 D:\Apps\node\node.exe，
     换电脑要改成本机 node 的实际位置。
  2. 环境变量 LIVE_ALLOW_PRIVATE=1 不能少。LibreTV 自带 SSRF 防护，
     没有这个变量它会把指向 127.0.0.1 的「本地加速」源当非法地址拒掉，
     加速直接失效。

【首次打开某部片要等约 3 秒】
  源站对单连接限速，这一片没有预取可借，是链路的物理下限。
  之后的分片走预取缓存，基本秒出。

【排错】
  localhost:3000 打不开        → 看 PowerShell 窗口的报错，它会停住等你回车
  localhost:3001/api/health    → 看加速器是否活着、各源状态
  搜索一直转圈                 → 多半是源都挂了，换源
