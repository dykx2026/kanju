#!/usr/bin/env node
/**
 * HLS 加速代理 + 播放器
 * ------------------------------------------------------------------
 * 为什么需要它：
 *   实测这些采集源对「单条连接」限速在 110~140 KB/s，但同一 IP 开 16 条连接
 *   合计能跑 1200 KB/s（11 倍）。浏览器里的 hls.js 是逐个分片顺序取的，永远
 *   只吃得到 110 KB/s。1080p 流码率约 919 kbps ≈ 115 KB/s —— 下载比播放还慢，
 *   所以必然反复缓冲。
 *   本服务在本地替播放器「提前并行下载」后面若干分片，播放器取第 N 片时
 *   N+1..N+16 已经在路上了，单连接客户端也能吃到多连接的总带宽。
 *
 * 用法：  node hls_accel.js [端口]     默认 3001
 *        浏览器打开 http://127.0.0.1:3001/
 */
'use strict';

const http = require('http');
const https = require('https');
const path = require('path');
const fs = require('fs');
const { URL } = require('url');

const PORT = parseInt(process.argv[2], 10) || 3001;
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const PREFETCH = 22;      // 预取窗口：播放头之后提前抓多少片
const CONCURRENCY = 10;   // 预取并发（当前片另有分段并发，别把总连接数堆太高）
const FAST_PARTS = 6;     // 播放器等的那一片切成几段并发
const KEEP_MAX = 140;     // 每个流按片数兜底
const KEEP_BYTES = 120 * 1024 * 1024; // 每个流按字节兜底，避免多流吃爆内存
const PLAYLIST_TTL = 45000;   // 清单缓存：拖进度条/重试别每次重下 200KB
const RESOLVE_TTL = 600000;   // 播放页→m3u8 的解析结果缓存（一次要 2 秒以上）
const RETRY = 3;          // 单片失败重试次数
const SEG_TIMEOUT = 25000; // 单片超时

/* ------------------------------ 上游抓取 ------------------------------ */

// 复用连接：每个分片新建一次 TLS 握手，慢源站上要 200~600ms，几十片累积就是好几秒
const AGENT_HTTP = new http.Agent({ keepAlive: true, maxSockets: 48, maxFreeSockets: 24 });
const AGENT_HTTPS = new https.Agent({ keepAlive: true, maxSockets: 48, maxFreeSockets: 24 });

function upGet(urlStr, opts = {}) {
  return new Promise((resolve) => {
    let u;
    try { u = new URL(urlStr); } catch (e) { return resolve({ ok: false, err: 'bad url' }); }
    const lib = u.protocol === 'https:' ? https : http;
    const t0 = Date.now();
    const req = lib.get(u, {
      agent: u.protocol === 'https:' ? AGENT_HTTPS : AGENT_HTTP,
      headers: {
        'User-Agent': UA,
        'Accept': '*/*',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        ...(opts.referer ? { 'Referer': opts.referer } : {}),
        ...(opts.range ? { 'Range': opts.range } : {}),
      },
      timeout: opts.timeout || 30000,
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        let next;
        try { next = new URL(res.headers.location, u).href; } catch (e) { return resolve({ ok: false, err: 'bad redirect' }); }
        return upGet(next, opts).then(resolve);
      }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({
        ok: true, code: res.statusCode, body: Buffer.concat(chunks),
        headers: res.headers, ms: Date.now() - t0,
      }));
    });
    req.on('error', (e) => resolve({ ok: false, err: e.message }));
    req.setTimeout(opts.timeout || 30000, () => { req.destroy(); resolve({ ok: false, err: 'timeout' }); });
  });
}

function text(urlStr, opts) {
  return upGet(urlStr, opts).then((r) => {
    if (!r || !r.ok || !r.body || !r.body.length) return '';
    if (r.code === 200) return r.body.toString('utf8');
    if (r.code === 206 && /bytes\s+0-/.test(String((r.headers && r.headers['content-range']) || ''))) {
      return r.body.toString('utf8');
    }
    return '';
  });
}

/** 抓一片，失败自动重试（源站偶发 5xx / 连接被掐，重试一次多半就好） */
// 源站有时对没有 Range 的请求也回 206，但 content-range 是 bytes 0-x/total，
// 也就是完整内容。只认 200 会把这类分片一律判成失败（之前第 10、11 片就是这么挂的）。
function isFullOk(r) {
  if (!r || !r.ok || !r.body || !r.body.length) return false;
  if (r.code === 200) return true;
  if (r.code === 206) {
    const cr = String((r.headers && r.headers['content-range']) || '');
    const m = /bytes\s+(\d+)-(\d+)\/(\d+)/.exec(cr);
    if (!m) return false;
    return parseInt(m[1], 10) === 0 && parseInt(m[2], 10) + 1 === parseInt(m[3], 10);
  }
  return false;
}

/**
 * 播放器正在等的这一片：切成若干 Range 段并发拉。
 * 这些源站对单连接限速约 160KB/s，一个 800KB 的片要 5 秒；
 * 切 4~8 段后实测 240~307KB/s，起播和卡顿时明显更快。
 * 任何一段出错/长度对不上就整片退回到单连接重试，宁可慢不要坏。
 */
async function fetchSegFast(url, referer) {
  const probe = await upGet(url, { referer, timeout: SEG_TIMEOUT, range: 'bytes=0-1023' });
  if (!probe || !probe.ok || !probe.body || !probe.body.length) return fetchSegOnce(url, referer, RETRY);
  if (probe.code !== 206) {
    // 服务器不认 Range，直接给了整个文件，那就用这份
    if (isFullOk(probe)) return probe.body;
    return fetchSegOnce(url, referer, RETRY);
  }
  const m = /bytes\s+(\d+)-(\d+)\/(\d+)/.exec(String((probe.headers && probe.headers['content-range']) || ''));
  if (!m) return fetchSegOnce(url, referer, RETRY);
  const total = parseInt(m[3], 10);
  if (!(total > 0)) return fetchSegOnce(url, referer, RETRY);
  // 探测那一下正好把整片都返回了，别浪费
  if (parseInt(m[1], 10) === 0 && parseInt(m[2], 10) + 1 === total) return probe.body;

  const partSize = Math.max(128 * 1024, Math.ceil(total / FAST_PARTS));
  const ranges = [];
  for (let st0 = 0; st0 < total; st0 += partSize) {
    ranges.push([st0, Math.min(total - 1, st0 + partSize - 1)]);
  }
  const chunks = await Promise.all(ranges.map(async ([a, b]) => {
    const want = b - a + 1;
    for (let k = 0; k <= RETRY; k++) {
      const r = await upGet(url, { referer, timeout: SEG_TIMEOUT, range: 'bytes=' + a + '-' + b });
      if (r && r.ok && r.body && r.body.length === want) return r.body;
      if (k < RETRY) await new Promise((z) => setTimeout(z, 250 * (k + 1)));
    }
    return null;
  }));
  if (chunks.some((c) => !c)) return fetchSegOnce(url, referer, RETRY);
  const out = Buffer.concat(chunks);
  if (out.length !== total) return fetchSegOnce(url, referer, RETRY);
  return out;
}

async function fetchSegOnce(url, referer, tries) {
  for (let k = 0; k <= tries; k++) {
    const r = await upGet(url, { referer, timeout: SEG_TIMEOUT });
    if (isFullOk(r)) return r.body;
    if (k < tries) await new Promise((s) => setTimeout(s, 300 * (k + 1)));
  }
  return null;
}

/* --------------------------- 每个播放列表的状态 --------------------------- */
// key = 该 m3u8 的绝对地址
// value = { segs, referer, cache:Map<idx,Buffer>, pending:Map<idx,Promise>, order:[] }
const streams = new Map();

function getStream(key) {
  let st = streams.get(key);
  if (!st) {
    st = {
      segs: [], referer: key, cache: new Map(), pending: new Map(), order: [],
      bytes: 0, head: 0, filled: false, loadedAt: 0, text: '', refillScheduled: false,
    };
    streams.set(key, st);
  }
  return st;
}

/** 放一片进缓存，按「片数 + 字节」双重上限淘汰最旧的 */
function putCache(st, i, buf) {
  if (st.cache.has(i)) return;
  st.cache.set(i, buf);
  st.order.push(i);
  st.bytes += buf.length;
  // 播放头前后的片不能淘汰，否则刚下好又被删，等于白干
  const keepFrom = Math.max(0, (st.head || 0) - 2);
  while (st.order.length && (st.order.length > KEEP_MAX || st.bytes > KEEP_BYTES)) {
    const o = st.order.shift();
    if (o >= keepFrom) { st.order.push(o); break; }
    const b = st.cache.get(o);
    if (b) { st.bytes -= b.length; st.cache.delete(o); }
  }
}

function pruneStreams() {
  if (streams.size > 12) {
    for (const k of [...streams.keys()].slice(0, streams.size - 12)) streams.delete(k);
  }
}

function b64u(s) {
  return Buffer.from(s, 'utf8').toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function absUrl(raw, base) {
  const r = String(raw || '').trim();
  if (!r) return '';
  if (/^https?:/i.test(r)) return r;
  try { return new URL(r, base).href; } catch (e) { return ''; }
}
function unb64u(s) {
  let t = String(s || '').replace(/-/g, '+').replace(/_/g, '/');
  while (t.length % 4) t += '=';
  try { return Buffer.from(t, 'base64').toString('utf8'); } catch (e) { return ''; }
}

/* ----------------------------- m3u8 重写 ----------------------------- */

function isPlaylistUrl(u) { return /\.m3u8(\?|$)/i.test(u); }

/**
 * 把 m3u8 里所有地址改写成本地代理地址。
 * 关键：先判 .m3u8（子播放列表），再判分片。不能靠 /hls/ 这类路径猜，
 *      因为子列表地址里也常带 /hls/ —— 之前就栽在这。
 */
function rewriteM3u8(body, m3u8Url, referer, base) {
  const B = base || '';
  const out = [];
  const lines = body.split(/\r?\n/);
  let idx = 0;
  const segs = [];
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) { out.push(raw); continue; }

    if (line.startsWith('#')) {
      const t = raw.replace(/URI="([^"]+)"/g, (m, uri) => {
        let abs;
        try { abs = new URL(uri, m3u8Url).href; } catch (e) { return m; }
        return 'URI="' + B + '/raw?u=' + b64u(abs) + '&r=' + b64u(referer || '') + '"';
      });
      out.push(t);
      continue;
    }

    let abs;
    try { abs = new URL(line, m3u8Url).href; } catch (e) { out.push(raw); continue; }

    if (isPlaylistUrl(abs)) {
      out.push(B + '/m?u=' + b64u(abs) + '&r=' + b64u(referer || ''));
      continue;
    }

    segs.push(abs);
    out.push(B + '/seg?p=' + b64u(m3u8Url) + '&i=' + idx + '&u=' + b64u(abs) + '&r=' + b64u(referer || ''));
    idx++;
  }
  return { text: out.join('\n'), segs };
}

/* ------------------------------ 并行预取 ------------------------------ */

function startSeg(st, i) {
  const p = fetchSegOnce(st.segs[i], st.referer, RETRY)
    .then((buf) => {
      st.pending.delete(i);
      if (buf) putCache(st, i, buf);
      scheduleRefill(st);
      return buf;
    })
    .catch(() => { st.pending.delete(i); scheduleRefill(st); return null; });
  st.pending.set(i, p);
  return p;
}

function refill(st) {
  if (!st || !st.segs.length) return;
  const from = Math.max(0, st.head || 0);
  const end = Math.min(st.segs.length, from + PREFETCH);
  for (let i = from; i < end; i++) {
    if (st.pending.size >= CONCURRENCY) break;
    if (st.cache.has(i) || st.pending.has(i)) continue;
    startSeg(st, i);
  }
}

/**
 * 自我续期：一片下完立刻补下一片。
 * 原来只在播放器来要的时候才补，池子一空就彻底停摆 ——
 * 表现正是「开头十几秒很顺，之后每片都要等一整个下载周期」。
 */
function scheduleRefill(st) {
  if (st.refillScheduled) return;
  st.refillScheduled = true;
  setImmediate(() => { st.refillScheduled = false; try { refill(st); } catch (e) {} });
}

async function getSeg(st, i) {
  if (st.cache.has(i)) return st.cache.get(i);
  if (st.pending.has(i)) {
    const b = await st.pending.get(i);
    if (b) return b;
  }
  if (!st.segs[i]) return null;
  startSeg(st, i);
  return (await st.pending.get(i)) || null;
}

/** 拉一个 m3u8 并把分片表灌进状态 */
async function loadPlaylist(m3u8Url, referer, base) {
  const st = getStream(m3u8Url);
  if (referer) st.referer = referer;
  // 清单缓存：拖进度条、解码重试、切码率都会重拉清单，
  // 慢源站拉一次 200KB 的清单要 2 秒以上，不能每次都重来。
  if (st.filled && st.text && Date.now() - st.loadedAt < PLAYLIST_TTL) {
    return { ok: true, text: st.text, st, isMaster: st.segs.length === 0 };
  }
  const body = await text(m3u8Url, { referer: referer || m3u8Url, timeout: 20000 });
  if (!body || !body.includes('#EXTM3U')) return { ok: false, err: 'm3u8 拉不下来', st };
  const rw = rewriteM3u8(body, m3u8Url, referer || m3u8Url, base);
  st.segs = rw.segs;
  st.text = rw.text;
  st.filled = true;
  st.loadedAt = Date.now();
  // 立刻开始预取，别等播放器来要
  try { refill(st); } catch (e) {}
  return { ok: true, text: rw.text, st, isMaster: rw.segs.length === 0 };
}

/* ------------------------------ 源站搜索 ------------------------------ */

const SOURCES = [
  // 发布版：不内置任何采集源。
  // 源地址写在仓库根目录 README.md 的「播放源」一节，按需自己填进来。
  // 保持空数组时，搜索会提示没有可用源，不会报错。
];

async function searchAll(wd) {
  const tasks = SOURCES.map((s) =>
    text(s.api + '/?ac=videolist&wd=' + encodeURIComponent(wd), { timeout: 9000 })
      .then((b) => {
        if (!b) return [];
        let j;
        try { j = JSON.parse(b); } catch (e) { return []; }
        return (j.list || []).map((v) => ({
          src: s.name,
          name: String(v.vod_name || ''),
          remarks: String(v.vod_remarks || ''),
          year: String(v.vod_year || ''),
          eps: (v.vod_play_url || '').split('#').map((x) => {
            const p = x.split('$');
            return { t: p[0], u: p[1] || '' };
          }).filter((e) => e.u),
        }));
      })
      .catch(() => [])
  );
  const all = (await Promise.all(tasks)).flat();
  const byName = new Map();
  for (const it of all) {
    if (!it.name) continue;
    if (!byName.has(it.name)) byName.set(it.name, { name: it.name, remarks: it.remarks, year: it.year, bySrc: [] });
    byName.get(it.name).bySrc.push({ src: it.src, eps: it.eps });
  }
  return [...byName.values()];
}

/* ------------------------------- 页面 ------------------------------- */

function htmlIndex() {
  return `<!doctype html><html lang="zh"><head><meta charset="utf-8">
<title>HLS 加速播放器</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#0f1115;color:#e8eaed;font:14px/1.6 "Microsoft YaHei",system-ui,sans-serif}
.wrap{max-width:1000px;margin:0 auto;padding:26px 20px 60px}
h1{font-size:20px;margin:0 0 4px;font-weight:600}
.sub{color:#8b93a1;font-size:12.5px;margin-bottom:20px}
.bar{display:flex;gap:8px;margin-bottom:16px}
input{flex:1;background:#1a1e26;border:1px solid #2a303c;color:#e8eaed;padding:11px 14px;border-radius:8px;font-size:14px;outline:none}
input:focus{border-color:#3d7eff}
button{background:#3d7eff;border:0;color:#fff;padding:11px 22px;border-radius:8px;font-size:14px;cursor:pointer}
button:hover{background:#2f6ae0}
button:disabled{background:#2a303c;color:#68707e;cursor:default}
.hint{background:#151922;border:1px solid #222834;border-radius:8px;padding:11px 14px;font-size:12.5px;color:#98a0ae;margin-bottom:18px;line-height:1.75}
.hint b{color:#ffca4d}
.item{border-bottom:1px solid #1c212b;padding:12px 0}
.item .t{font-size:14.5px;font-weight:600}
.item .m{color:#7d8592;font-size:12px;margin-left:8px;font-weight:400}
.srcs{margin-top:7px;display:flex;flex-wrap:wrap;gap:6px;max-height:150px;overflow-y:auto}
.ep{background:#1a1e26;border:1px solid #2a303c;color:#b8c0cc;padding:4px 10px;border-radius:6px;font-size:12px;cursor:pointer;user-select:none}
.ep:hover{border-color:#3d7eff;color:#fff}
.ep .s{color:#5b6373;margin-right:5px}
#msg{color:#8b93a1;font-size:12.5px;min-height:20px;margin-bottom:10px}
video{width:100%;background:#000;border-radius:8px;display:block}
#player{display:none;margin-bottom:18px}
#stat{font-size:11.5px;color:#6b7382;margin-top:6px;font-family:Consolas,monospace}
</style></head><body><div class="wrap">
<h1>HLS 加速播放器</h1>
<div class="sub">并行预取分片 · 让被单连接限速的源站也能跑满带宽</div>
<div id="player"><video id="v" controls autoplay playsinline></video><div id="stat"></div></div>
<div class="bar"><input id="q" placeholder="输入片名搜索，例如：流浪地球" autocomplete="off"><button id="go">搜索</button></div>
<div class="hint">这些采集源对<b>单条连接</b>限速约 110 KB/s，而 1080p 流要 115 KB/s，所以原版播放器必然卡。这里用 <b>${CONCURRENCY} 条连接并行预取</b>，实测带宽可提升到 <b>10 倍以上</b>。</div>
<div id="msg"></div>
<div id="list"></div>
</div>
<script>
var $ = function (s) { return document.querySelector(s); };
var msg = function (t) { $('#msg').textContent = t; };
var hls = null, statTimer = null;

function b64u(s) {
  var utf8 = new TextEncoder().encode(s);
  var bin = '';
  utf8.forEach(function (b) { bin += String.fromCharCode(b); });
  return btoa(bin).replace(/\\+/g, '-').replace(/\\//g, '_').replace(/=+$/, '');
}
function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function doSearch() {
  var wd = $('#q').value.trim();
  if (!wd) return;
  $('#go').disabled = true;
  msg('正在搜索 ' + ${SOURCES.length} + ' 个源…');
  $('#list').innerHTML = '';
  fetch('/search?wd=' + encodeURIComponent(wd))
    .then(function (r) { return r.json(); })
    .then(function (j) {
      if (!j.items || !j.items.length) { msg('没搜到，换个片名试试'); return; }
      msg('找到 ' + j.items.length + ' 部，点击任意一个源开始播放');
      render(j.items);
    })
    .catch(function (e) { msg('搜索失败：' + e.message); })
    .then(function () { $('#go').disabled = false; });
}

function render(items) {
  var box = $('#list');
  box.innerHTML = '';
  items.forEach(function (it) {
    var d = document.createElement('div');
    d.className = 'item';
    var eps = it.bySrc.map(function (s) {
      if (!s.eps.length) return '<span class="ep">无剧集</span>';
      return s.eps.map(function (e, i) {
        return '<span class="ep" data-u="' + esc(e.u) + '" data-t="' + esc(it.name + ' ' + e.t) + '">' +
          '<span class="s">' + esc(s.src) + '</span>' + esc(e.t || String(i + 1)) + '</span>';
      }).join('');
    }).join('');
    d.innerHTML = '<div class="t">' + esc(it.name) + '<span class="m">' +
      esc([it.year, it.remarks].filter(Boolean).join(' · ')) + '</span></div>' +
      '<div class="srcs">' + eps + '</div>';
    box.appendChild(d);
  });
  var nodes = box.querySelectorAll('.ep');
  for (var i = 0; i < nodes.length; i++) {
    (function (el) {
      el.addEventListener('click', function () { play(el.getAttribute('data-u'), el.getAttribute('data-t')); });
    })(nodes[i]);
  }
}

function play(url, title) {
  msg('正在解析：' + title);
  $('#player').style.display = 'block';
  var v = $('#v');
  fetch('/resolve?u=' + encodeURIComponent(url))
    .then(function (r) { return r.json(); })
    .then(function (j) {
      if (!j.ok) { msg('解析失败：' + (j.err || '未知')); return; }
      var m3u8 = '/m?u=' + b64u(j.m3u8) + '&r=' + b64u(url);
      if (hls) { hls.destroy(); hls = null; }
      if (statTimer) { clearInterval(statTimer); statTimer = null; }
      if (window.Hls && Hls.isSupported()) {
        hls = new Hls({
          maxBufferLength: 90,
          maxMaxBufferLength: 240,
          maxBufferSize: 200 * 1024 * 1024,
          manifestLoadingMaxRetry: 6,
          levelLoadingMaxRetry: 6,
          fragLoadingMaxRetry: 10,
          fragLoadingRetryDelay: 700,
          enableWorker: true,
          lowLatencyMode: false,
          startLevel: -1
        });
        hls.loadSource(m3u8);
        hls.attachMedia(v);
        hls.on(Hls.Events.ERROR, function (e, d) {
          if (d.fatal) msg('播放出错：' + d.details + '（换个源再试）');
        });
        statTimer = setInterval(function () {
          var buf = 0;
          for (var k = 0; k < v.buffered.length; k++) {
            if (v.currentTime >= v.buffered.start(k) - 1 && v.currentTime <= v.buffered.end(k)) {
              buf = v.buffered.end(k) - v.currentTime;
            }
          }
          var lv = '';
          try {
            if (hls && hls.levels && hls.currentLevel >= 0) {
              lv = Math.round(hls.levels[hls.currentLevel].bitrate / 1000) + 'kbps';
            }
          } catch (e2) {}
          $('#stat').textContent = '缓冲 ' + buf.toFixed(1) + 's · 预取 ' + ${PREFETCH} + ' 片 · 并发 ' + ${CONCURRENCY} + ' · ' + lv;
        }, 1000);
      } else {
        v.src = m3u8;
      }
      v.play().catch(function () {});
      msg('正在播放：' + title);
    })
    .catch(function (e) { msg('出错：' + e.message); });
}

$('#go').addEventListener('click', doSearch);
$('#q').addEventListener('keydown', function (e) { if (e.key === 'Enter') doSearch(); });
</script>
<script src="/hls.min.js"></script>
</body></html>`;
}


/* ---------------- 伪装成苹果CMS 源，供 LibreTV 直接添加 ---------------- */
// 为什么这么做：LibreTV 的播放地址只收 $http...m3u8 形式，所以给它一个
// 「源」比改它的前端代码干净得多 —— 它自己的搜索、播放器、进度条全保留，
// 我们只在地址中间插一个本地 m3u8，分片请求就都落到加速器上了。

const SELF_BASE = 'http://127.0.0.1:' + PORT;

function cmsEpUrl(raw) { return SELF_BASE + '/play/' + b64u(raw) + '.m3u8'; }

function cmsSend(res, obj) {
  const b = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': b.length,
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store',
  });
  res.end(b);
}

/** 搜索：并发问所有源，合并成一份 list。截图式给 LibreTV 用。 */
const searchCache = new Map();

async function cmsSearch(wd) {
  const hit = searchCache.get(wd);
  if (hit && Date.now() - hit.t < 30000) return hit.v;
  const byKey = new Map();
  await Promise.all(SOURCES.map(async (src, si) => {
    const body = await text(src.api + '/?ac=videolist&wd=' + encodeURIComponent(wd), { timeout: 3500 });
    if (!body) return;
    let j;
    try { j = JSON.parse(body); } catch (e) { return; }
    for (const v of (j.list || [])) {
      const name = String(v.vod_name || '');
      if (!name) continue;
      // 集数按「最长的那条线路」算
      let n = 0;
      for (const ln of String(v.vod_play_url || '').split('$$$')) {
        const c = ln.split('#').filter((x) => x.split('$')[1]).length;
        if (c > n) n = c;
      }
      const key = si + '|' + name;
      const prev = byKey.get(key);
      // 同一源里同名的重复条目（不同 id），留集数多的那个
      if (prev && prev.n >= n) continue;
      byKey.set(key, {
        n,
        item: {
          vod_id: 's' + si + '-' + String(v.vod_id || ''),
          vod_name: name,
          vod_pic: String(v.vod_pic || ''),
          vod_remarks: '[' + src.name + '] ' + String(v.vod_remarks || '') + (n ? ' · ' + n + '集' : ''),
          vod_play_url: '第1集$' + SELF_BASE + '/play/' + b64u('s' + si + '-' + String(v.vod_id || '')) + '.m3u8',
          type_name: String(v.type_name || ''),
          vod_year: String(v.vod_year || ''),
          vod_area: String(v.vod_area || ''),
        },
      });
    }
  }));
  const out = [...byKey.values()].map((x) => x.item);
  searchCache.set(wd, { t: Date.now(), v: out });
  if (searchCache.size > 40) searchCache.delete(searchCache.keys().next().value);
  return out;
}

/** 详情：拿某一集的真实播放地址，改写成加速器地址 */
async function cmsDetail(si, realId) {
  const src = SOURCES[si];
  if (!src) return null;
  const body = await text(src.api + '/?ac=videolist&ids=' + encodeURIComponent(realId), { timeout: 8000 });
  if (!body) return null;
  let j;
  try { j = JSON.parse(body); } catch (e) { return null; }
  const v = (j.list || [])[0];
  if (!v) return null;
  // 源站的 vod_play_url 可能是「多线路」，用 $$$ 分隔（线路1共36集$$$线路2共35集）。
  // 直接按 # 拆会把两条线路串成一条：36 集的片子变成 71 个条目、集号还重复。
  const lines = String(v.vod_play_url || '').split('$$$').map((ln) =>
    ln.split('#')
      .map((x) => x.split('$'))
      .filter((p) => p && p[1] && /^(https?:|\/)/i.test(p[1]))
      .map((p) => ({ t: String(p[0] || '').trim(), u: absUrl(p[1], src.api) }))
      .filter((e) => e.u)
  ).filter((ln) => ln.length);
  // 取集数最多的线路（并列时优先含 m3u8 的）
  lines.sort((a, b) => (b.length - a.length)
    || (b.filter((e) => /\.m3u8/i.test(e.u)).length - a.filter((e) => /\.m3u8/i.test(e.u)).length));
  const eps = lines.length ? lines[0] : [];
  const playUrl = eps.map((p, i) =>
    (p.t || ('第' + (i + 1) + '集')) + '$' + cmsEpUrl(p.u)).join('#');
  return {
    vod_id: 's' + si + '-' + realId,
    vod_name: String(v.vod_name || ''),
    vod_pic: String(v.vod_pic || ''),
    vod_remarks: '[' + src.name + '] ' + String(v.vod_remarks || ''),
    type_name: String(v.type_name || ''),
    vod_year: String(v.vod_year || ''),
    vod_area: String(v.vod_area || ''),
    vod_play_url: playUrl,
  };
}

/** CMS 请求入口：ac=videolist&wd= 搜索，ac=videolist&ids= 详情 */
async function cmsHandle(res, u) {
  const ac = u.searchParams.get('ac') || '';
  const wd = u.searchParams.get('wd') || '';
  const ids = u.searchParams.get('ids') || '';
  if (ac !== 'videolist') return cmsSend(res, { code: 0, msg: 'only ac=videolist', list: [] });
  if (ids) {
    // 新格式 s<源号>-<点播id>；老格式 <源号>|<点播id> 仍然认
    let si = -1, realId = '';
    const m1 = /^s(\d+)-(.+)$/.exec(ids);
    if (m1) { si = parseInt(m1[1], 10); realId = m1[2]; }
    else {
      const bar = ids.indexOf('|');
      if (bar > 0) { si = parseInt(ids.slice(0, bar), 10); realId = ids.slice(bar + 1); }
    }
    if (!(si >= 0) || !realId) return cmsSend(res, { code: 0, msg: 'bad ids', list: [] });
    const one = await cmsDetail(si, realId);
    return cmsSend(res, {
      code: 1, msg: 'ok', page: 1, pagecount: 1, limit: '20', total: one ? 1 : 0,
      list: one ? [one] : [],
    });
  }
  if (!wd) return cmsSend(res, { code: 1, msg: 'ok', page: 1, pagecount: 1, limit: '20', total: 0, list: [] });
  const list = await cmsSearch(wd);
  return cmsSend(res, {
    code: 1, msg: 'ok', page: 1, pagecount: 1, limit: '20', total: list.length, list,
  });
}

/* ------------------------------ HTTP ------------------------------ */

function send(res, code, body, type) {
  const b = Buffer.isBuffer(body) ? body : Buffer.from(String(body), 'utf8');
  res.writeHead(code, {
    'Content-Type': type || 'text/plain; charset=utf-8',
    'Content-Length': b.length,
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store',
  });
  res.end(b);
}

// 一个请求出错绝不允许带走整个进程：CMS 详情里一条坏地址曾经让 node 直接退出，
// 表现就是「源突然变少 / 集数不全」。兜住之后只丢这一条请求。
process.on('uncaughtException', (e) => {
  console.log('[uncaught] ' + (e && e.message ? e.message : e));
});
process.on('unhandledRejection', (e) => {
  console.log('[unhandled] ' + (e && e.message ? e.message : e));
});

const server = http.createServer(async (req, res) => {
  let u;
  try { u = new URL(req.url, 'http://127.0.0.1:' + PORT); }
  catch (e) { res.writeHead(400); return res.end('bad url'); }
  const p = u.pathname;
  try {
    // 带 ac= 的一律走 CMS 兼容层（LibreTV 的详情页会请求站点根路径）
    if (u.searchParams.get('ac')) { return cmsHandle(res, u); }

    if (p.startsWith('/play/') && p.endsWith('.m3u8')) {
      const raw = unb64u(p.slice(6, -5));
      if (!raw) return send(res, 400, 'bad token');
      let realUrl = raw;
      const lm = /^s(\d+)-(.+)$/.exec(raw);
      if (lm) {
        const one = await cmsDetail(parseInt(lm[1], 10), lm[2]);
        if (!one || !one.vod_play_url) return send(res, 502, 'detail failed');
        realUrl = one.vod_play_url.split('#')[0].split('$')[1] || '';
        if (!realUrl) return send(res, 502, 'no episode url');
      }
      const rv = await resolveCached(realUrl);
      if (!rv.ok) return send(res, 502, rv.err);
      if (rv.direct) {
        res.writeHead(302, { Location: rv.m3u8, 'Access-Control-Allow-Origin': '*' });
        return res.end();
      }
      const pl = await loadPlaylist(rv.m3u8, realUrl, SELF_BASE);
      if (!pl.ok) return send(res, 502, pl.err);
      return send(res, 200, pl.text, 'application/vnd.apple.mpegurl; charset=utf-8');
    }

    if (p === '/' || p === '/index.html') return send(res, 200, htmlIndex(), 'text/html; charset=utf-8');

    if (p === '/hls.min.js') {
      const f = path.join(__dirname, 'hls.min.js');
      if (!fs.existsSync(f)) return send(res, 404, 'hls.min.js missing');
      return send(res, 200, fs.readFileSync(f), 'application/javascript');
    }

    if (p === '/search') {
      const wd = u.searchParams.get('wd') || '';
      if (!wd) return send(res, 200, JSON.stringify({ items: [] }), 'application/json');
      const items = await searchAll(wd);
      items.sort((a, b) => b.bySrc.length - a.bySrc.length);
      return send(res, 200, JSON.stringify({ items }), 'application/json');
    }

    if (p === '/resolve') {
      const raw = u.searchParams.get('u') || '';
      return send(res, 200, JSON.stringify(await resolvePlayUrl(raw)), 'application/json');
    }

    if (p === '/m') {
      const src = unb64u(u.searchParams.get('u'));
      const ref = unb64u(u.searchParams.get('r'));
      if (!src) return send(res, 400, 'no url');
      const r = await loadPlaylist(src, ref || src, SELF_BASE);
      if (!r.ok) return send(res, 502, r.err);
      return send(res, 200, r.text, 'application/vnd.apple.mpegurl');
    }

    if (p === '/seg') {
      const pl = unb64u(u.searchParams.get('p'));
      const segUrl = unb64u(u.searchParams.get('u'));
      const ref = unb64u(u.searchParams.get('r'));
      const i = parseInt(u.searchParams.get('i'), 10);
      if (!pl || !segUrl || isNaN(i)) return send(res, 400, 'bad args');
      let st = getStream(pl);
      if (ref) st.referer = ref;
      if (!st.segs.length) {
        await loadPlaylist(pl, ref || pl);
        st = getStream(pl);
      }
      if (!st.segs[i]) st.segs[i] = segUrl;
      // 播放头跟着播放器走，预取窗口永远围绕它
      if (i > (st.head || 0)) st.head = i;
      // 要的这一片优先：缓存有直接给；在飞就等它（不要另开一条重复下）；
      // 两边都没有就立刻起一条。旧代码在这里无条件重新 fetch，
      // 与预取撞车，同一片下两遍还互相抢带宽。
      let buf = st.cache.get(i);
      if (!buf) {
        // 播放器要的这一片永远走分段并发。预取是单连接，慢源站一片要 4~5 秒，
        // 比一段视频本身还长，等它必然卡。预取槽位当场腾出来，别让它白占着。
        const pend = st.pending.get(i) || null;
        if (pend) st.pending.delete(i);
        buf = await fetchSegFast(st.segs[i], st.referer);
        if (!buf && pend) buf = await pend;
        if (buf) putCache(st, i, buf);
      }
      refill(st);
      if (!buf) return send(res, 502, 'segment fetch failed');
      return send(res, 200, buf, 'video/mp2t');
    }

    if (p === '/raw') {
      const src = unb64u(u.searchParams.get('u'));
      const ref = unb64u(u.searchParams.get('r'));
      if (!src) return send(res, 400, 'no url');
      const r = await upGet(src, { referer: ref || src });
      if (!isFullOk(r)) return send(res, 502, 'raw fetch failed');
      return send(res, 200, r.body, r.headers['content-type'] || 'application/octet-stream');
    }

    if (p === '/debug') {
      const pl = unb64u(u.searchParams.get('p'));
      const st = streams.get(pl);
      if (!st) return send(res, 404, 'no such stream');
      return send(res, 200, JSON.stringify({
        segs: st.segs.length, cached: st.cache.size, pending: st.pending.size,
        order: st.order.slice(-12),
      }), 'application/json');
    }

    return send(res, 404, 'not found');
  } catch (e) {
    return send(res, 500, 'error: ' + e.message);
  }
});

/* ------------------------ 播放地址解析（含 HTML 页） ------------------------ */

const resolveCache = new Map();

async function resolveCached(u) {
  const hit = resolveCache.get(u);
  if (hit && Date.now() - hit.t < RESOLVE_TTL) return hit.v;
  const v = await resolvePlayUrl(u);
  resolveCache.set(u, { t: Date.now(), v });
  if (resolveCache.size > 200) resolveCache.delete(resolveCache.keys().next().value);
  return v;
}

async function resolvePlayUrl(raw) {
  if (!raw) return { ok: false, err: '空地址' };
  if (!/^https?:/i.test(raw)) return { ok: false, err: '不是 http 地址' };

  if (isPlaylistUrl(raw)) {
    const b = await text(raw, { referer: raw });
    if (b && b.includes('#EXTM3U')) return { ok: true, m3u8: raw };
    return { ok: false, err: 'm3u8 拉不下来' };
  }
  if (/\.(mp4|m4v)(\?|$)/i.test(raw)) return { ok: true, m3u8: raw, direct: true };

  const page = await text(raw, { referer: raw });
  if (!page) return { ok: false, err: '播放页拉不下来（源站可能封了直连）' };

  const cands = page.match(/https?:\/\/[^"'\s\\<>]+?\.m3u8[^"'\s\\<>]*/g) || [];
  for (const c of cands) {
    const m = c.replace(/\\\//g, '/');
    const b = await text(m, { referer: raw });
    if (b && b.includes('#EXTM3U')) return { ok: true, m3u8: m };
  }
  // 有些站给的是相对路径：const url = "/20230114/xxx/index.m3u8?sign=...";
  // 直接拼成绝对地址再试一次。之前只匹配绝对地址，这类站点全被判成「解析失败」。
  const rels = page.match(/["'\s(]((?:\/|\.\/)[^"'\s<>]+\.m3u8[^"'\s<>]*)/g) || [];
  for (const cand of rels) {
    const m1 = /((?:\/|\.\/)[^"'\s<>]+\.m3u8[^"'\s<>]*)/.exec(cand);
    if (!m1) continue;
    let abs;
    try { abs = new URL(m1[1], raw).href; } catch (e) { continue; }
    const b = await text(abs, { referer: raw });
    if (b && b.includes('#EXTM3U')) return { ok: true, m3u8: abs };
  }

  const m2 = page.match(/"url"\s*:\s*"([^"]+?\.m3u8[^"]*)"/);
  if (m2) {
    let m = m2[1].replace(/\\\//g, '/');
    try { m = new URL(m, raw).href; } catch (e) {}
    const b = await text(m, { referer: raw });
    if (b && b.includes('#EXTM3U')) return { ok: true, m3u8: m };
  }
  return { ok: false, err: '播放页里没找到 m3u8（可能是 JS 动态生成）' };
}

/* ------------------------------ 启动 ------------------------------ */

setInterval(pruneStreams, 60000).unref();

server.listen(PORT, '127.0.0.1', () => {
  console.log('HLS 加速代理: http://127.0.0.1:' + PORT);
  console.log('预取窗口 ' + PREFETCH + ' 片 / 并发 ' + CONCURRENCY + ' / 保留 ' + KEEP_MAX + ' 片或 ' + Math.round(KEEP_BYTES/1048576) + 'MB / 重试 ' + RETRY);
});

process.on('SIGINT', () => { console.log('退出'); process.exit(0); });
process.on('SIGTERM', () => process.exit(0));
